<?php
/**
 * @version   1.7.0.1 May 14, 2012
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2012 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

class Rockettheme_HomepageTabs_Helper_Data extends Mage_Core_Helper_Abstract
{
    
}