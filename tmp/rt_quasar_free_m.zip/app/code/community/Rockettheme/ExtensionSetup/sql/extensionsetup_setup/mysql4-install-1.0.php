<?php

// This file is just a place holder - replace this with your theme's extension settings version